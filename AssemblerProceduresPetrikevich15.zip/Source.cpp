#include <iostream>
using namespace std;

extern "C" int __cdecl ArrayLocalExtremum(int*,int);//the 4th option(__cdecl with parametrs)
extern "C" int __stdcall ArrayLocalExtremum1(int*, int);
extern "C" int __cdecl ArrayLocalExtremum2(int*, int);
extern "C" int __stdcall ArrayLocalExtremum3(int*, int);
extern "C" int __fastcall ArrayLocalExtremum5(int*, int);

int main()
{
	int len = 11;
	int* mas = new int[len]{0,1,2,3,4,5,4,3,2,1,0};
	for (int i = 0; i < 11; i++)
	{
		cout << mas[i] << " ";
	}
	cout << "\n";
	cout << ArrayLocalExtremum(mas, len) << "\n";
	cout << ArrayLocalExtremum1(mas, len) << "\n";
	cout << ArrayLocalExtremum2(mas, len) << "\n";
	cout << ArrayLocalExtremum3(mas, len) << "\n";
	cout << ArrayLocalExtremum5(mas, len) << "\n";
}
